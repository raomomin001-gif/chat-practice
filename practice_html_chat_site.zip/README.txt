How to use this practice file:

1) Open github.com
2) Create New Repository
3) Upload index.html and style.css
4) Open index.html
5) Paste tawk.to code before </body>
6) Save and publish with GitHub Pages

This is only for practice.
